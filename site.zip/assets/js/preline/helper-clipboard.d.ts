declare function clipboardHelper(selector: string): void;

export {
	clipboardHelper as default,
};

export {};
